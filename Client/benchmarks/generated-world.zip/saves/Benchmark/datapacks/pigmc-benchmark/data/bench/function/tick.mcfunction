scoreboard players add @a bench 1
execute as @a at @s run tp @s ~0.15 100 ~ ~2 15
execute as @a[scores={bench=200..}] run tp @s -128 100 -128 0 15
scoreboard players set @a[scores={bench=200..}] bench 0
